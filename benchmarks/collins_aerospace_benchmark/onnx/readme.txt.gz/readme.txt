# COLLINS AEROSPACE
# THIS FILE CONTAINS NO EU OR US EXPORT-CONTROLLED TECHNICAL DATA
# YOLO model architecture is based on https://github.com/ultralytics/yolov5/blob/master/ by Ultralytics
# Trained on: SeaDronesSee dataset: https://seadronessee.cs.uni-tuebingen.de/home
# Distribution: AGPL-3.0 license